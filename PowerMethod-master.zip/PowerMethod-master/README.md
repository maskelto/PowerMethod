# PowerMethod
CSC302 Introduction to Numerical Methods: Power Method Implementation
